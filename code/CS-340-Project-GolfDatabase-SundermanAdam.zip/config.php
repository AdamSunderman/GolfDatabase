<?php
define (mUSER, "sunderad-db");
define (mPASS, "f0YfFLX9K5HB3RUT");
define (mDB, "sunderad-db");
define (mHOST, "oniddb.cws.oregonstate.edu");

?>


